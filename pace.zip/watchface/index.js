try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const logger = Logger.getLogger('pace');
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {

      const N = hmUI.show_level.ONLY_NORMAL;
      const AOD = hmUI.show_level.ONLY_AOD;
      const safe = (f) => { try { return f(); } catch (e) { console.log('widget error', e); return null; } };
      const empty = 'empty.png';
      const sensor = (id) => { try { return hmSensor.createSensor(hmSensor.id[id]); } catch (e) { return null; } };

      // characters drawn with images (values the face computes itself)
      const HL = {"0": ["hl_0.png", 7], "1": ["hl_1.png", 4], "2": ["hl_2.png", 6], "3": ["hl_3.png", 6], "4": ["hl_4.png", 6], "5": ["hl_5.png", 6], "6": ["hl_6.png", 6], "7": ["hl_7.png", 6], "8": ["hl_8.png", 7], "9": ["hl_9.png", 6], "°": ["hl_deg.png", 4], "/": ["hl_sl.png", 4], " ": ["hl_sp.png", 1], "-": ["hl_m.png", 4]};
      const VAL = {"0": ["val_0.png", 12], "1": ["val_1.png", 8], "2": ["val_2.png", 12], "3": ["val_3.png", 11], "4": ["val_4.png", 12], "5": ["val_5.png", 12], "6": ["val_6.png", 12], "7": ["val_7.png", 11], "8": ["val_8.png", 13], "9": ["val_9.png", 12], "-": ["val_m.png", 8]};
      const charRow = (n, y, show) => {
        const ws = [];
        for (let i = 0; i < n; i++) ws.push(hmUI.createWidget(hmUI.widget.IMG, { x: 0, y, src: empty, show_level: show }));
        return ws;
      };
      const setChars = (ws, map, text, x, y, align) => {
        const chars = String(text).split('').filter((c) => map[c]);
        const total = chars.reduce((s, c) => s + map[c][1], 0);
        let cx = align === 'center' ? Math.round(x - total / 2) : align === 'right' ? x - total : x;
        ws.forEach((w, i) => {
          const c = chars[i];
          if (c) {
            w.setProperty(hmUI.prop.MORE, { x: cx, y, src: map[c][0] });
            w.setProperty(hmUI.prop.VISIBLE, true);
            cx += map[c][1];
          } else {
            w.setProperty(hmUI.prop.VISIBLE, false);
          }
        });
      };

      // ---------------- normal screen
      hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'bg.png', show_level: N });
      const secBase = { center_x: 240, center_y: 240, radius: 235, start_angle: 0, end_angle: 360, color: 0xC6F432, line_width: 3, show_level: N };
      const secArc = safe(() => hmUI.createWidget(hmUI.widget.ARC_PROGRESS, Object.assign({ level: 0 }, secBase)));

      // heart-rate zone highlight, marker and pill
      const zoneImg = hmUI.createWidget(hmUI.widget.IMG, { x: 9, y: 51, src: 'zone_1.png', show_level: N });
      const marker = safe(() => hmUI.createWidget(hmUI.widget.IMG, {
        x: 0, y: 0, w: 480, h: 480, pos_x: 228, pos_y: 0, center_x: 240, center_y: 240, angle: 215, src: 'hrmark.png', show_level: N,
      }));
      const pill = hmUI.createWidget(hmUI.widget.IMG, { x: 131, y: 321, src: 'zpill_1.png', show_level: N });

      // weekly PAI arc
      safe(() => hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 330, y: 60, image_array: ["pai_00.png", "pai_02.png", "pai_04.png", "pai_06.png", "pai_08.png", "pai_10.png", "pai_12.png", "pai_14.png", "pai_16.png", "pai_18.png", "pai_20.png"], image_length: 11,
        type: hmUI.data_type.PAI_WEEKLY, show_level: N,
      }));

      // battery
      safe(() => hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 220, y: 39, image_array: ["batfill_00.png", "batfill_01.png", "batfill_02.png", "batfill_03.png", "batfill_04.png", "batfill_05.png", "batfill_06.png", "batfill_07.png", "batfill_08.png", "batfill_09.png", "batfill_10.png", "batfill_11.png", "batfill_12.png", "batfill_13.png"], image_length: 14,
        type: hmUI.data_type.BATTERY, show_level: N,
      }));
      if (hmUI.data_type.BATTERY !== undefined) safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 241, y: 36, w: 30, h: 13,
        font_array: ["bat_0.png", "bat_1.png", "bat_2.png", "bat_3.png", "bat_4.png", "bat_5.png", "bat_6.png", "bat_7.png", "bat_8.png", "bat_9.png"], h_space: 0, padding: false, align_h: hmUI.align.LEFT,
        type: hmUI.data_type.BATTERY, show_level: N,
      }));

      // date
      safe(() => hmUI.createWidget(hmUI.widget.IMG_WEEK, {
        x: 181, y: 60,
        week_en: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"], week_tc: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"], week_sc: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"], show_level: N,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.IMG_DATE, {
        day_startX: 229, day_startY: 60,
        day_sc_array: ["dday_0.png", "dday_1.png", "dday_2.png", "dday_3.png", "dday_4.png", "dday_5.png", "dday_6.png", "dday_7.png", "dday_8.png", "dday_9.png"], day_tc_array: ["dday_0.png", "dday_1.png", "dday_2.png", "dday_3.png", "dday_4.png", "dday_5.png", "dday_6.png", "dday_7.png", "dday_8.png", "dday_9.png"], day_en_array: ["dday_0.png", "dday_1.png", "dday_2.png", "dday_3.png", "dday_4.png", "dday_5.png", "dday_6.png", "dday_7.png", "dday_8.png", "dday_9.png"],
        day_zero: 1, day_space: 0, day_align: hmUI.align.LEFT, day_is_character: false, show_level: N,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.IMG_DATE, {
        month_startX: 259, month_startY: 60,
        month_sc_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"], month_tc_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"], month_en_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"],
        month_is_character: true, show_level: N,
      }));

      // weather row
      safe(() => hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 133, y: 90, image_array: ["wicon_cloud.png", "wicon_rain.png", "wicon_snow.png", "wicon_sun.png", "wicon_cloud.png", "wicon_rain.png", "wicon_snow.png", "wicon_rain.png", "wicon_snow.png", "wicon_snow.png", "wicon_rain.png", "wicon_fog.png", "wicon_snow.png", "wicon_fog.png", "wicon_fog.png", "wicon_storm.png", "wicon_snow.png", "wicon_fog.png", "wicon_storm.png", "wicon_storm.png", "wicon_storm.png", "wicon_rain.png", "wicon_fog.png", "wicon_fog.png", "wicon_rain.png", "wicon_cloud.png", "wicon_cloud.png", "wicon_rain.png", "wicon_moon.png"], image_length: 29,
        type: hmUI.data_type.WEATHER_CURRENT, show_level: N,
      }));
      if (hmUI.data_type.WEATHER_CURRENT !== undefined) safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 128, y: 90, w: 50, h: 19,
        font_array: ["tmp_0.png", "tmp_1.png", "tmp_2.png", "tmp_3.png", "tmp_4.png", "tmp_5.png", "tmp_6.png", "tmp_7.png", "tmp_8.png", "tmp_9.png"], h_space: 0, padding: false, align_h: hmUI.align.RIGHT,
        unit_en: 'tmp_deg.png', unit_sc: 'tmp_deg.png', unit_tc: 'tmp_deg.png', negative_image: 'tmp_m.png', invalid_image: 'tmp_m.png',
        type: hmUI.data_type.WEATHER_CURRENT, show_level: N,
      }));

      const hilo = charRow(9, 92, N);
      if (hmUI.data_type.SUN_RISE !== undefined) safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 269, y: 88, w: 44, h: 23,
        font_array: ["sun_0.png", "sun_1.png", "sun_2.png", "sun_3.png", "sun_4.png", "sun_5.png", "sun_6.png", "sun_7.png", "sun_8.png", "sun_9.png"], h_space: 0, padding: false, align_h: hmUI.align.LEFT,
        dot_image: 'sun_col.png',
        type: hmUI.data_type.SUN_RISE, show_level: N,
      }));

      if (hmUI.data_type.SUN_SET !== undefined) safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 323, y: 88, w: 44, h: 23,
        font_array: ["sun_0.png", "sun_1.png", "sun_2.png", "sun_3.png", "sun_4.png", "sun_5.png", "sun_6.png", "sun_7.png", "sun_8.png", "sun_9.png"], h_space: 0, padding: false, align_h: hmUI.align.LEFT,
        dot_image: 'sun_col.png',
        type: hmUI.data_type.SUN_SET, show_level: N,
      }));

      // time
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        hour_startX: 123, hour_startY: 110, hour_array: ["th_0.png", "th_1.png", "th_2.png", "th_3.png", "th_4.png", "th_5.png", "th_6.png", "th_7.png", "th_8.png", "th_9.png"],
        hour_zero: 1, hour_space: 0, hour_align: hmUI.align.LEFT, show_level: N,
      });
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        minute_startX: 241, minute_startY: 110, minute_array: ["tm_0.png", "tm_1.png", "tm_2.png", "tm_3.png", "tm_4.png", "tm_5.png", "tm_6.png", "tm_7.png", "tm_8.png", "tm_9.png"],
        minute_zero: 1, minute_space: 0, minute_align: hmUI.align.LEFT, show_level: N,
      });
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        second_startX: 380, second_startY: 134, second_array: ["tsec_0.png", "tsec_1.png", "tsec_2.png", "tsec_3.png", "tsec_4.png", "tsec_5.png", "tsec_6.png", "tsec_7.png", "tsec_8.png", "tsec_9.png"],
        second_zero: 1, second_space: 0, second_align: hmUI.align.LEFT, show_level: N,
      });

      // steps
      if (hmUI.data_type.STEP !== undefined) safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 168, y: 236, w: 80, h: 21,
        font_array: ["stp_0.png", "stp_1.png", "stp_2.png", "stp_3.png", "stp_4.png", "stp_5.png", "stp_6.png", "stp_7.png", "stp_8.png", "stp_9.png"], h_space: 0, padding: false, align_h: hmUI.align.RIGHT,
        type: hmUI.data_type.STEP, show_level: N,
      }));

      safe(() => hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 132, y: 254, image_array: ["stepbar_00.png", "stepbar_01.png", "stepbar_02.png", "stepbar_03.png", "stepbar_04.png", "stepbar_05.png", "stepbar_06.png", "stepbar_07.png", "stepbar_08.png", "stepbar_09.png", "stepbar_10.png", "stepbar_11.png", "stepbar_12.png", "stepbar_13.png", "stepbar_14.png", "stepbar_15.png", "stepbar_16.png", "stepbar_17.png", "stepbar_18.png", "stepbar_19.png", "stepbar_20.png"], image_length: 21,
        type: hmUI.data_type.STEP, show_level: N,
      }));

      // tiles
      if (hmUI.data_type.HEART !== undefined) safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 65, y: 310, w: 90, h: 28,
        font_array: ["val_0.png", "val_1.png", "val_2.png", "val_3.png", "val_4.png", "val_5.png", "val_6.png", "val_7.png", "val_8.png", "val_9.png"], h_space: 0, padding: false, align_h: hmUI.align.CENTER_H,
        invalid_image: 'val_m.png',
        type: hmUI.data_type.HEART, show_level: N,
      }));

      if (hmUI.data_type.PAI_WEEKLY !== undefined) safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 195, y: 310, w: 90, h: 28,
        font_array: ["val_0.png", "val_1.png", "val_2.png", "val_3.png", "val_4.png", "val_5.png", "val_6.png", "val_7.png", "val_8.png", "val_9.png"], h_space: 0, padding: false, align_h: hmUI.align.CENTER_H,
        type: hmUI.data_type.PAI_WEEKLY, show_level: N,
      }));

      const sono = charRow(3, 310, N);
      if (hmUI.data_type.SPO2 !== undefined) safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 85, y: 368, w: 90, h: 28,
        font_array: ["val_0.png", "val_1.png", "val_2.png", "val_3.png", "val_4.png", "val_5.png", "val_6.png", "val_7.png", "val_8.png", "val_9.png"], h_space: 0, padding: false, align_h: hmUI.align.CENTER_H,
        invalid_image: 'val_m.png',
        type: hmUI.data_type.SPO2, show_level: N,
      }));

      if (hmUI.data_type.STRESS !== undefined) safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 195, y: 368, w: 90, h: 28,
        font_array: ["val_0.png", "val_1.png", "val_2.png", "val_3.png", "val_4.png", "val_5.png", "val_6.png", "val_7.png", "val_8.png", "val_9.png"], h_space: 0, padding: false, align_h: hmUI.align.CENTER_H,
        invalid_image: 'val_m.png',
        type: hmUI.data_type.STRESS, show_level: N,
      }));

      if (hmUI.data_type.CAL !== undefined) safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 305, y: 368, w: 90, h: 28,
        font_array: ["val_0.png", "val_1.png", "val_2.png", "val_3.png", "val_4.png", "val_5.png", "val_6.png", "val_7.png", "val_8.png", "val_9.png"], h_space: 0, padding: false, align_h: hmUI.align.CENTER_H,
        type: hmUI.data_type.CAL, show_level: N,
      }));

      // weekly PAI bars
      const WX = [186, 202, 216, 232, 246, 262, 276];
      const bars = WX.map((x) => hmUI.createWidget(hmUI.widget.IMG, { x, y: 398, src: 'wkd_00.png', show_level: N }));

      // ---------------- always-on screen
      hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'aod_bg.png', show_level: AOD });
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        hour_startX: 98, hour_startY: 168, hour_array: ["ah_0.png", "ah_1.png", "ah_2.png", "ah_3.png", "ah_4.png", "ah_5.png", "ah_6.png", "ah_7.png", "ah_8.png", "ah_9.png"],
        hour_zero: 1, hour_space: 0, hour_align: hmUI.align.LEFT, show_level: AOD,
      });
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        minute_startX: 239, minute_startY: 168, minute_array: ["am_0.png", "am_1.png", "am_2.png", "am_3.png", "am_4.png", "am_5.png", "am_6.png", "am_7.png", "am_8.png", "am_9.png"],
        minute_zero: 1, minute_space: 0, minute_align: hmUI.align.LEFT, show_level: AOD,
      });
      safe(() => hmUI.createWidget(hmUI.widget.IMG_WEEK, {
        x: 172, y: 135,
        week_en: ["aweek_1.png", "aweek_2.png", "aweek_3.png", "aweek_4.png", "aweek_5.png", "aweek_6.png", "aweek_7.png"], week_tc: ["aweek_1.png", "aweek_2.png", "aweek_3.png", "aweek_4.png", "aweek_5.png", "aweek_6.png", "aweek_7.png"], week_sc: ["aweek_1.png", "aweek_2.png", "aweek_3.png", "aweek_4.png", "aweek_5.png", "aweek_6.png", "aweek_7.png"], show_level: AOD,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.IMG_DATE, {
        day_startX: 227, day_startY: 135,
        day_sc_array: ["aday_0.png", "aday_1.png", "aday_2.png", "aday_3.png", "aday_4.png", "aday_5.png", "aday_6.png", "aday_7.png", "aday_8.png", "aday_9.png"], day_tc_array: ["aday_0.png", "aday_1.png", "aday_2.png", "aday_3.png", "aday_4.png", "aday_5.png", "aday_6.png", "aday_7.png", "aday_8.png", "aday_9.png"], day_en_array: ["aday_0.png", "aday_1.png", "aday_2.png", "aday_3.png", "aday_4.png", "aday_5.png", "aday_6.png", "aday_7.png", "aday_8.png", "aday_9.png"],
        day_zero: 1, day_space: 0, day_align: hmUI.align.LEFT, day_is_character: false, show_level: AOD,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.IMG_DATE, {
        month_startX: 263, month_startY: 135,
        month_sc_array: ["amonth_1.png", "amonth_2.png", "amonth_3.png", "amonth_4.png", "amonth_5.png", "amonth_6.png", "amonth_7.png", "amonth_8.png", "amonth_9.png", "amonth_10.png", "amonth_11.png", "amonth_12.png"], month_tc_array: ["amonth_1.png", "amonth_2.png", "amonth_3.png", "amonth_4.png", "amonth_5.png", "amonth_6.png", "amonth_7.png", "amonth_8.png", "amonth_9.png", "amonth_10.png", "amonth_11.png", "amonth_12.png"], month_en_array: ["amonth_1.png", "amonth_2.png", "amonth_3.png", "amonth_4.png", "amonth_5.png", "amonth_6.png", "amonth_7.png", "amonth_8.png", "amonth_9.png", "amonth_10.png", "amonth_11.png", "amonth_12.png"],
        month_is_character: true, show_level: AOD,
      }));
      const INFO = ["ainfo_0.png", "ainfo_1.png", "ainfo_2.png", "ainfo_3.png", "ainfo_4.png", "ainfo_5.png", "ainfo_6.png", "ainfo_7.png", "ainfo_8.png", "ainfo_9.png"];
      [['HEART', 172, 330, 36], ['STEP', 240, 330, 52], ['BATTERY', 301, 330, 28]].forEach(([k, x, y, w]) => {
        if (hmUI.data_type[k] === undefined) return;
        safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x, y, w, h: 18, font_array: INFO, h_space: 0, padding: false, align_h: hmUI.align.LEFT,
          type: hmUI.data_type[k], show_level: AOD,
        }));
      });

      // ---------------- live values the face computes
      const timeS = sensor('TIME');
      const heartS = sensor('HEART');
      const paiS = sensor('PAI');
      const sleepS = sensor('SLEEP');
      const weatherS = sensor('WEATHER');
      const ZB = [0, 114, 133, 152, 171];

      const updateHeart = () => {
        const bpm = heartS ? (heartS.last || heartS.current || 0) : 0;
        let z = 0;
        for (let i = 0; i < 5; i++) if (bpm >= ZB[i]) z = i;
        zoneImg.setProperty(hmUI.prop.SRC, `zone_${z + 1}.png`);
        pill.setProperty(hmUI.prop.SRC, `zpill_${z + 1}.png`);
        const t = Math.max(0, Math.min(1, (bpm - 90) / 100));
        if (marker) marker.setProperty(hmUI.prop.ANGLE, Math.round(215 + t * 110));
      };
      const updateSlow = () => {
        // today's high / low
        try {
          const f = weatherS && weatherS.getForecastWeather();
          const d = f && f.forecastData && f.forecastData.data && f.forecastData.data[0];
          setChars(hilo, HL, d ? `${d.high}°/${d.low}°` : '--', 185, 92, 'left');
        } catch (e) { setChars(hilo, HL, '--', 185, 92, 'left'); }
        // sleep score
        let score = 0;
        try { const info = sleepS && sleepS.getBasicInfo(); score = (info && info.score) || 0; } catch (e) { score = 0; }
        setChars(sono, VAL, score > 0 ? String(score) : '--', 358, 310, 'center');
        // PAI of the last 7 days (today lit, on the right)
        if (paiS) {
          const days = [paiS.prepai5, paiS.prepai4, paiS.prepai3, paiS.prepai2, paiS.prepai1, paiS.prepai0, paiS.dailypai]
            .map((v) => (typeof v === 'number' && v > 0 ? v : 0));
          const max = Math.max(1, ...days);
          days.forEach((v, i) => {
            const h = v > 0 ? Math.max(3, Math.round((v / max) * 24)) : 3;
            bars[i].setProperty(hmUI.prop.SRC, `wk${i === 6 ? 'l' : 'd'}_${String(h).padStart(2, '0')}.png`);
          });
        }
        updateHeart();
      };
      let secTimer = null;
      const tick = () => {
        if (!secArc || !timeS) return;
        secArc.setProperty(hmUI.prop.MORE, Object.assign({ level: Math.round((timeS.second || 0) / 60 * 100) }, secBase));
      };
      const startTick = () => { if (!secTimer) secTimer = timer.createTimer(0, 1000, tick, {}); };
      const stopTick = () => { if (secTimer) { timer.stopTimer(secTimer); secTimer = null; } };

      if (heartS) { try { heartS.addEventListener(heartS.event.LAST, updateHeart); } catch (e) {} }
      if (timeS) { try { timeS.addEventListener(timeS.event.MINUTEEND, updateSlow); } catch (e) {} }
      updateSlow();

      // ---------------- taps (created last so nothing covers them)
      const button = (x, y, w, h, fn) => safe(() => hmUI.createWidget(hmUI.widget.BUTTON, {
        x, y, w, h, text: '', normal_src: empty, press_src: empty, click_func: fn, show_level: N,
      }));
      const shortcut = (x, y, w, h, kind, alt) => {
        const k = hmUI.data_type[kind] !== undefined ? kind : alt;
        if (!k || hmUI.data_type[k] === undefined) return;
        safe(() => hmUI.createWidget(hmUI.widget.IMG_CLICK, { x, y, w, h, type: hmUI.data_type[k], show_level: N }));
      };
      const open = (url) => () => { try { hmApp.startApp({ url, native: true }); } catch (e) { console.log(e); } };
      button(140, 54, 200, 28, open('ScheduleCalScreen'));
      button(196, 28, 88, 22, open('PowerSaveHintScreen'));
      shortcut(110, 84, 120, 28, 'WEATHER_CURRENT');
      shortcut(232, 84, 140, 28, 'SUN_CURRENT', 'WEATHER_CURRENT');
      shortcut(96, 114, 260, 118, 'ALARM_CLOCK');
      shortcut(358, 114, 50, 50, 'STOP_WATCH');
      shortcut(130, 236, 220, 44, 'STEP');
      shortcut(66, 292, 112, 46, 'HEART');
      shortcut(184, 292, 112, 46, 'PAI_WEEKLY');
      shortcut(302, 292, 112, 46, 'SLEEP');
      shortcut(78, 350, 104, 46, 'SPO2');
      shortcut(188, 350, 104, 46, 'STRESS');
      shortcut(298, 350, 104, 46, 'CAL', 'STEP');
      shortcut(150, 402, 180, 46, 'PAI_WEEKLY');

      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: () => { updateSlow(); startTick(); },
        pause_call: () => { stopTick(); },
      });
      startTick();

      },
      onInit() {},
      build() {
        this.init_view();
      },
      onDestroy() {},
    });
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log('error stack', i));
}
