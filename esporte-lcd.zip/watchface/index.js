try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const logger = Logger.getLogger('esporte');
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {

      const N = hmUI.show_level.ONLY_NORMAL;
      const AOD = hmUI.show_level.ONLY_AOD;
      const safe = (f) => { try { return f(); } catch (e) { console.log('widget error', e); return null; } };
      const empty = 'empty.png';
      let lightTimer = null;

      // ---------------- normal screen
      const bg = hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'bg.png', show_level: N });

      safe(() => hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 312, y: 108, image_array: ["gauge_00.png", "gauge_01.png", "gauge_02.png", "gauge_03.png", "gauge_04.png", "gauge_05.png", "gauge_06.png", "gauge_07.png", "gauge_08.png", "gauge_09.png", "gauge_10.png", "gauge_11.png", "gauge_12.png", "gauge_13.png", "gauge_14.png", "gauge_15.png", "gauge_16.png"], image_length: 17,
        type: hmUI.data_type.BATTERY, show_level: N,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 324, y: 136, w: 46, h: 27,
        font_array: ["d20_0.png", "d20_1.png", "d20_2.png", "d20_3.png", "d20_4.png", "d20_5.png", "d20_6.png", "d20_7.png", "d20_8.png", "d20_9.png"], h_space: -4, padding: false, align_h: hmUI.align.RIGHT,
        invalid_image: 'd20_m.png', negative_image: 'd20_m.png',
        type: hmUI.data_type.BATTERY, show_level: N,
      }));

      safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 109, y: 89, w: 84, h: 37,
        font_array: ["d30_0.png", "d30_1.png", "d30_2.png", "d30_3.png", "d30_4.png", "d30_5.png", "d30_6.png", "d30_7.png", "d30_8.png", "d30_9.png"], h_space: -4, padding: false, align_h: hmUI.align.RIGHT,
        invalid_image: 'd30_m.png', negative_image: 'd30_m.png',
        type: hmUI.data_type.CAL, show_level: N,
      }));

      safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 221, y: 89, w: 64, h: 37,
        font_array: ["d30_0.png", "d30_1.png", "d30_2.png", "d30_3.png", "d30_4.png", "d30_5.png", "d30_6.png", "d30_7.png", "d30_8.png", "d30_9.png"], h_space: -4, padding: false, align_h: hmUI.align.RIGHT,
        invalid_image: 'd30_m.png', negative_image: 'd30_m.png',
        type: hmUI.data_type.HEART, show_level: N,
      }));

      safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 95, y: 143, w: 94, h: 33,
        font_array: ["d26_0.png", "d26_1.png", "d26_2.png", "d26_3.png", "d26_4.png", "d26_5.png", "d26_6.png", "d26_7.png", "d26_8.png", "d26_9.png"], h_space: -4, padding: false, align_h: hmUI.align.RIGHT,
        invalid_image: 'd26_m.png', negative_image: 'd26_m.png',
        type: hmUI.data_type.STEP, show_level: N,
      }));

      safe(() => hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 191, y: 159, image_array: ["meta_0.png", "meta_1.png", "meta_2.png", "meta_3.png", "meta_4.png", "meta_5.png", "meta_6.png"], image_length: 7,
        type: hmUI.data_type.STEP, show_level: N,
      }));

      // date banner: weekday, day, month
      safe(() => hmUI.createWidget(hmUI.widget.IMG_WEEK, {
        x: 98, y: 191,
        week_en: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"], week_tc: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"], week_sc: ["week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png", "week_7.png"],
        show_level: N,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.IMG_DATE, {
        day_startX: 148, day_startY: 192,
        day_sc_array: ["dd17_0.png", "dd17_1.png", "dd17_2.png", "dd17_3.png", "dd17_4.png", "dd17_5.png", "dd17_6.png", "dd17_7.png", "dd17_8.png", "dd17_9.png"], day_tc_array: ["dd17_0.png", "dd17_1.png", "dd17_2.png", "dd17_3.png", "dd17_4.png", "dd17_5.png", "dd17_6.png", "dd17_7.png", "dd17_8.png", "dd17_9.png"], day_en_array: ["dd17_0.png", "dd17_1.png", "dd17_2.png", "dd17_3.png", "dd17_4.png", "dd17_5.png", "dd17_6.png", "dd17_7.png", "dd17_8.png", "dd17_9.png"],
        day_zero: 1, day_space: -4, day_align: hmUI.align.LEFT, day_is_character: false, show_level: N,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.IMG_DATE, {
        month_startX: 178, month_startY: 192,
        month_sc_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"], month_tc_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"], month_en_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"],
        month_is_character: true, show_level: N,
      }));

      // weather: icon on the round button, condition name, temperature
      safe(() => hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 80, y: 234, image_array: ["wicon_cloud.png", "wicon_rain.png", "wicon_snow.png", "wicon_sun.png", "wicon_cloud.png", "wicon_rain.png", "wicon_snow.png", "wicon_rain.png", "wicon_snow.png", "wicon_snow.png", "wicon_rain.png", "wicon_fog.png", "wicon_snow.png", "wicon_fog.png", "wicon_fog.png", "wicon_storm.png", "wicon_snow.png", "wicon_fog.png", "wicon_storm.png", "wicon_storm.png", "wicon_storm.png", "wicon_rain.png", "wicon_fog.png", "wicon_fog.png", "wicon_rain.png", "wicon_cloud.png", "wicon_cloud.png", "wicon_rain.png", "wicon_moon.png"], image_length: 29,
        type: hmUI.data_type.WEATHER_CURRENT, show_level: N,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 241, y: 235, image_array: ["cond_00.png", "cond_01.png", "cond_02.png", "cond_03.png", "cond_04.png", "cond_05.png", "cond_06.png", "cond_07.png", "cond_08.png", "cond_09.png", "cond_10.png", "cond_11.png", "cond_12.png", "cond_13.png", "cond_14.png", "cond_15.png", "cond_16.png", "cond_17.png", "cond_18.png", "cond_19.png", "cond_20.png", "cond_21.png", "cond_22.png", "cond_23.png", "cond_24.png", "cond_25.png", "cond_26.png", "cond_27.png", "cond_28.png"], image_length: 29,
        type: hmUI.data_type.WEATHER_CURRENT, show_level: N,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 340, y: 229, w: 52, h: 29,
        font_array: ["d21_0.png", "d21_1.png", "d21_2.png", "d21_3.png", "d21_4.png", "d21_5.png", "d21_6.png", "d21_7.png", "d21_8.png", "d21_9.png"], h_space: -4, padding: false, align_h: hmUI.align.RIGHT,
        invalid_image: 'd21_m.png', negative_image: 'd21_m.png',
        type: hmUI.data_type.WEATHER_CURRENT, show_level: N,
      }));

      // time
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        hour_startX: 93, hour_startY: 278, hour_array: ["tb_0.png", "tb_1.png", "tb_2.png", "tb_3.png", "tb_4.png", "tb_5.png", "tb_6.png", "tb_7.png", "tb_8.png", "tb_9.png"],
        hour_zero: 1, hour_space: -4, hour_align: hmUI.align.LEFT, show_level: N,
      });
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        minute_startX: 216, minute_startY: 278, minute_array: ["tb_0.png", "tb_1.png", "tb_2.png", "tb_3.png", "tb_4.png", "tb_5.png", "tb_6.png", "tb_7.png", "tb_8.png", "tb_9.png"],
        minute_zero: 1, minute_space: -4, minute_align: hmUI.align.LEFT, show_level: N,
      });
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        second_startX: 338, second_startY: 301, second_array: ["ts_0.png", "ts_1.png", "ts_2.png", "ts_3.png", "ts_4.png", "ts_5.png", "ts_6.png", "ts_7.png", "ts_8.png", "ts_9.png"],
        second_zero: 1, second_space: -4, second_align: hmUI.align.LEFT, show_level: N,
      });

      // distance and blood oxygen
      safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 158, y: 383, w: 59, h: 23,
        font_array: ["d16_0.png", "d16_1.png", "d16_2.png", "d16_3.png", "d16_4.png", "d16_5.png", "d16_6.png", "d16_7.png", "d16_8.png", "d16_9.png"], h_space: -4, padding: false, align_h: hmUI.align.RIGHT,
        dot_image: 'dist_dot.png', invalid_image: 'd16_m.png',
        type: hmUI.data_type.DISTANCE, show_level: N,
      }));
      if (hmUI.data_type.SPO2 !== undefined) {
      safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 299, y: 383, w: 37, h: 23,
        font_array: ["d16_0.png", "d16_1.png", "d16_2.png", "d16_3.png", "d16_4.png", "d16_5.png", "d16_6.png", "d16_7.png", "d16_8.png", "d16_9.png"], h_space: -4, padding: false, align_h: hmUI.align.RIGHT,
        invalid_image: 'd16_m.png', negative_image: 'd16_m.png',
        type: hmUI.data_type.SPO2, show_level: N,
      }));

      }

      // ---------------- always-on screen
      hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'aod_bg.png', show_level: AOD });
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        hour_startX: 78, hour_startY: 182, hour_array: ["aod_0.png", "aod_1.png", "aod_2.png", "aod_3.png", "aod_4.png", "aod_5.png", "aod_6.png", "aod_7.png", "aod_8.png", "aod_9.png"],
        hour_zero: 1, hour_space: -4, hour_align: hmUI.align.LEFT, show_level: AOD,
      });
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        minute_startX: 249, minute_startY: 182, minute_array: ["aod_0.png", "aod_1.png", "aod_2.png", "aod_3.png", "aod_4.png", "aod_5.png", "aod_6.png", "aod_7.png", "aod_8.png", "aod_9.png"],
        minute_zero: 1, minute_space: -4, minute_align: hmUI.align.LEFT, show_level: AOD,
      });
      safe(() => hmUI.createWidget(hmUI.widget.IMG_WEEK, {
        x: 156, y: 141,
        week_en: ["aod_week_1.png", "aod_week_2.png", "aod_week_3.png", "aod_week_4.png", "aod_week_5.png", "aod_week_6.png", "aod_week_7.png"], week_tc: ["aod_week_1.png", "aod_week_2.png", "aod_week_3.png", "aod_week_4.png", "aod_week_5.png", "aod_week_6.png", "aod_week_7.png"], week_sc: ["aod_week_1.png", "aod_week_2.png", "aod_week_3.png", "aod_week_4.png", "aod_week_5.png", "aod_week_6.png", "aod_week_7.png"],
        show_level: AOD,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.IMG_DATE, {
        day_startX: 224, day_startY: 141,
        day_sc_array: ["aod_day_0.png", "aod_day_1.png", "aod_day_2.png", "aod_day_3.png", "aod_day_4.png", "aod_day_5.png", "aod_day_6.png", "aod_day_7.png", "aod_day_8.png", "aod_day_9.png"], day_tc_array: ["aod_day_0.png", "aod_day_1.png", "aod_day_2.png", "aod_day_3.png", "aod_day_4.png", "aod_day_5.png", "aod_day_6.png", "aod_day_7.png", "aod_day_8.png", "aod_day_9.png"], day_en_array: ["aod_day_0.png", "aod_day_1.png", "aod_day_2.png", "aod_day_3.png", "aod_day_4.png", "aod_day_5.png", "aod_day_6.png", "aod_day_7.png", "aod_day_8.png", "aod_day_9.png"],
        day_zero: 1, day_space: 0, day_align: hmUI.align.LEFT, day_is_character: false, show_level: AOD,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.IMG_DATE, {
        month_startX: 268, month_startY: 141,
        month_sc_array: ["aod_month_1.png", "aod_month_2.png", "aod_month_3.png", "aod_month_4.png", "aod_month_5.png", "aod_month_6.png", "aod_month_7.png", "aod_month_8.png", "aod_month_9.png", "aod_month_10.png", "aod_month_11.png", "aod_month_12.png"], month_tc_array: ["aod_month_1.png", "aod_month_2.png", "aod_month_3.png", "aod_month_4.png", "aod_month_5.png", "aod_month_6.png", "aod_month_7.png", "aod_month_8.png", "aod_month_9.png", "aod_month_10.png", "aod_month_11.png", "aod_month_12.png"], month_en_array: ["aod_month_1.png", "aod_month_2.png", "aod_month_3.png", "aod_month_4.png", "aod_month_5.png", "aod_month_6.png", "aod_month_7.png", "aod_month_8.png", "aod_month_9.png", "aod_month_10.png", "aod_month_11.png", "aod_month_12.png"],
        month_is_character: true, show_level: AOD,
      }));
      safe(() => hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: 196, y: 321, w: 60, h: 20,
        font_array: ["aod_bat_0.png", "aod_bat_1.png", "aod_bat_2.png", "aod_bat_3.png", "aod_bat_4.png", "aod_bat_5.png", "aod_bat_6.png", "aod_bat_7.png", "aod_bat_8.png", "aod_bat_9.png"], h_space: 0, padding: false, align_h: hmUI.align.RIGHT,
        type: hmUI.data_type.BATTERY, show_level: AOD,
      }));
      hmUI.createWidget(hmUI.widget.IMG, { x: 258, y: 321, src: 'aod_pct.png', show_level: AOD });

      // ---------------- taps (created last so nothing covers them)
      const button = (x, y, w, h, fn) => safe(() => hmUI.createWidget(hmUI.widget.BUTTON, {
        x, y, w, h, text: '', normal_src: empty, press_src: empty, click_func: fn, show_level: N,
      }));
      const shortcut = (x, y, w, h, kind) => {
        if (hmUI.data_type[kind] === undefined) return;
        safe(() => hmUI.createWidget(hmUI.widget.IMG_CLICK, { x, y, w, h, type: hmUI.data_type[kind], show_level: N }));
      };
      const open = (url) => () => { try { hmApp.startApp({ url, native: true }); } catch (e) { console.log(e); } };
      // tap on the time: backlight for 3 s, like the light button of a digital watch
      button(60, 272, 268, 96, () => {
        bg.setProperty(hmUI.prop.SRC, 'bg_luz.png');
        if (lightTimer) timer.stopTimer(lightTimer);
        lightTimer = timer.createTimer(3000, 3000, () => {
          bg.setProperty(hmUI.prop.SRC, 'bg.png');
          if (lightTimer) timer.stopTimer(lightTimer);
          lightTimer = null;
        }, {});
      });
      button(334, 274, 86, 92, open('StopWatchScreen'));
      button(82, 188, 210, 28, open('ScheduleCalScreen'));
      button(68, 224, 348, 36, open('WeatherScreen'));
      button(108, 84, 86, 50, open('activityAppScreen'));
      button(196, 84, 92, 50, open('heart_app_Screen'));
      button(90, 136, 200, 42, open('activityAppScreen'));
      button(292, 88, 120, 120, open('Settings_batteryManagerScreen'));
      button(138, 380, 120, 30, open('SportListScreen'));
      button(264, 380, 96, 30, open('spo_HomeScreen'));

      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: () => {},
        pause_call: () => {
          if (lightTimer) { timer.stopTimer(lightTimer); lightTimer = null; }
          bg.setProperty(hmUI.prop.SRC, 'bg.png');
        },
      });

      },
      onInit() {},
      build() {
        this.init_view();
      },
      onDestroy() {},
    });
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log('error stack', i));
}
